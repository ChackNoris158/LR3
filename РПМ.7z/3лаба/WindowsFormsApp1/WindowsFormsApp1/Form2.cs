﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        double d1, d2, d3, d4, d5, d6, d7, d8, d9, st;

        private void Form1_Resize(object sender, EventArgs e)
        {
            this.Invalidate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int kv_ur = Convert.ToInt16(textBox1.Text);
            int kol_chas = Convert.ToInt16(textBox2.Text);
            bool flag = true;
            switch (kv_ur)
            {
                case 1: st = 3880; break;
                case 2: st = 4268; break;
                case 3: st = 5104; break;
                case 4: st = 5247; break;
                case 5: st = 6003; break;
                case 6: st = 6463; break;
                case 7: st = 6960; break;
                default:
                    {
                        MessageBox.Show("Неправильно введен ваш уровень");
                        flag = false;
                        textBox1.Clear();
                        textBox2.Clear();
                        break;
                    }
            }
            if (flag == true)
            {
                double z = st / 18 * kol_chas;
                if (checkBox1.Checked) d1 = 0.12 * z;
                if (checkBox2.Checked) d2 = 0.2 * st;
                if (checkBox3.Checked) d3 = 0.15 * st;
                if (checkBox4.Checked) d4 = 0.1 * st;
                if (checkBox5.Checked) d5 = 0.4 * z;

                if (radioButton2.Checked) d6 = 0.5 * z;
                if (radioButton3.Checked) d7 = 0.7 * z;
                if (radioButton4.Checked) d8 = 0.5 * z;

                d9 = 100;
                double d = d1 + d2 + d3 + d4 + d5 + d6 + d7 + d8 + d9;
                z = z + d;

                textBox3.Text = z.ToString();
                double pod_nal = 0.13 * z;

                textBox4.Text = pod_nal.ToString();
                double pens_nal = 0.01 * z;

                textBox5.Text = pens_nal.ToString();
                double itog = z - pod_nal - pens_nal;

                textBox6.Text = itog.ToString();
            }
        }
        


        public Form2()
        {
            InitializeComponent();
        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            string f = Microsoft.VisualBasic.Interaction.InputBox("Введите вашу фамилию", "Регистрация", "", -1, -1);
            string i = Microsoft.VisualBasic.Interaction.InputBox("Введите вашу фамилию", "Регистрация", "", -1, -1);
            string o= Microsoft.VisualBasic.Interaction.InputBox("Введите вашу фамилию", "Регистрация", "", -1, -1);
            this.Text = "Зарплата преподователя.  " + f + " " + i + " " + o;
            label1.Text= "Уважаемый(-ая) " + i + " " + o+"!Введите, пожалуйста, данные";

        }
    }
}
